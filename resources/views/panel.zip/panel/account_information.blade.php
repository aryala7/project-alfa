@extends('panel.layouts.main')
@section('content')
<div class="row">
    <div class="col-lg-12">
        <!--begin::Card-->
        <div class="card card-custom gutter-b example example-compact">
            <div class="card-header">
                <h3 class="card-title">2 Columns Form Layout</h3>
                <div class="card-toolbar">
                    <div class="example-tools justify-content-center">
                        <span class="example-toggle" data-toggle="tooltip" title="View code"></span>
                        <span class="example-copy" data-toggle="tooltip" title="Copy code"></span>
                    </div>
                </div>
            </div>
            <!--begin::Form-->
            <form class="form">
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-lg-6">
                            <label>Full Name:</label>
                            <input type="email" class="form-control" placeholder="Enter full name" />
                            <span class="form-text text-muted">Please enter your full name</span>
                        </div>
                        <div class="col-lg-6">
                            <label>Contact Number:</label>
                            <input type="email" class="form-control" placeholder="Enter contact number" />
                            <span class="form-text text-muted">Please enter your contact number</span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-6">
                            <label>Address:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Enter your address" />
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-map-marker"></i>
                                    </span>
                                </div>
                            </div>
                            <span class="form-text text-muted">Please enter your address</span>
                        </div>
                        <div class="col-lg-6">
                            <label>Postcode:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Enter your postcode" />
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-bookmark-o"></i>
                                    </span>
                                </div>
                            </div>
                            <span class="form-text text-muted">Please enter your postcode</span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-6">
                            <label>User Group:</label>
                            <div class="radio-inline">
                                <label class="radio radio-solid">
                                <input type="radio" name="example_2" checked="checked" value="2" />Sales Person
                                <span></span></label>
                                <label class="radio radio-solid">
                                <input type="radio" name="example_2" value="2" />Customer
                                <span></span></label>
                            </div>
                            <span class="form-text text-muted">Please select user group</span>
                        </div>
                    </div>
                    <!-- begin: Example Code-->
                    <div class="example-code mt-10">
                        <ul class="example-nav nav nav-tabs nav-bold nav-tabs-line nav-tabs-line-2x">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#example_code_html">HTML</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="example_code_html" role="tabpanel">
                                <div class="example-highlight">
                                    <pre style="height:400px">

                                    </pre>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end: Example Code-->
                </div>
                <div class="card-footer">
                    <div class="row">
                        <div class="col-lg-6">
                            <button type="reset" class="btn btn-primary mr-2">Save</button>
                            <button type="reset" class="btn btn-secondary">Cancel</button>
                        </div>
                        <div class="col-lg-6 text-right">
                            <button type="reset" class="btn btn-danger">Delete</button>
                        </div>
                    </div>
                </div>
            </form>
            <!--end::Form-->
        </div>
        <!--end::Card-->
    </div>
</div>
@endsection